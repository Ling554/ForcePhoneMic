rootProject.name = "ForcePhoneMic"
include(":app")
